import React, { useState } from "react";
import "../components/Header.css";
const ElementCart = () => {
  return (
        <div className="ElementCart">
          <div>Tovar</div>
          <div>112$</div>
        </div>
  );
};
export default ElementCart;
